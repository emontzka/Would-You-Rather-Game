export default from './ComponentDoc'
