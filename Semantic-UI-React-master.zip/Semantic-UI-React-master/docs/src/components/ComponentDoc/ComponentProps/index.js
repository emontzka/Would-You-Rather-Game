export default from './ComponentProps'
