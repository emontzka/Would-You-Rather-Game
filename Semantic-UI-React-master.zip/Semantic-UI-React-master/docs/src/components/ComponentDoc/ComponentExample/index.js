export default from './ComponentExample'
