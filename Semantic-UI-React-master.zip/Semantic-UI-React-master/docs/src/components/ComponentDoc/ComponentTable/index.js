export default from './ComponentTable'
