export default, { EDITOR_BACKGROUND_COLOR, EDITOR_GUTTER_COLOR } from './CodeEditorUniveral'
