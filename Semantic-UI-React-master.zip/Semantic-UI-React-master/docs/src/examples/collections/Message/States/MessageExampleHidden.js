import React from 'react'
import { Message } from 'semantic-ui-react'

const MessageExampleHidden = () => <Message hidden>You can't see me</Message>

export default MessageExampleHidden
