import React from 'react'
import { Button } from 'semantic-ui-react'

const ButtonExampleCircular = () => <Button circular icon='settings' />

export default ButtonExampleCircular
