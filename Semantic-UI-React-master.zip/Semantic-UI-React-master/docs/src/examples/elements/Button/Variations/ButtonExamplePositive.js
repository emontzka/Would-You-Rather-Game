import React from 'react'
import { Button } from 'semantic-ui-react'

const ButtonExamplePositive = () => (
  <div>
    <Button positive>Positive Button</Button>
  </div>
)

export default ButtonExamplePositive
