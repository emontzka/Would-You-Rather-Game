import React from 'react'
import Types from './Types'

const SelectExamples = () => (
  <div>
    <Types />
  </div>
)

export default SelectExamples
