import React from 'react'
import Types from './Types'

const RefExamples = () => (
  <div>
    <Types />
  </div>
)

export default RefExamples
