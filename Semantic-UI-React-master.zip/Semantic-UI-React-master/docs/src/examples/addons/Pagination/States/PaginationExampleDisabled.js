import React from 'react'
import { Pagination } from 'semantic-ui-react'

const PaginationExampleDisabled = () => <Pagination defaultActivePage={1} disabled totalPages={5} />

export default PaginationExampleDisabled
