---
name: 📓 Support Question
about: If you have a question 💬, please check out our Gitter or StackOverflow!

---

--------------^ Click "Preview" for a nicer view!
We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks! 😁.

---

* Gitter Community Chat: https://gitter.im/Semantic-Org/Semantic-UI-React
* StackOverflow: https://stackoverflow.com/questions/tagged/semantic-ui-react using the tag `semantic-ui-react`
* Also have a look at our docs: http://react.semantic-ui.com
